from xlrd import open_workbook
import xlrd
import datetime
import Include.library.writer as xwriter
from Include.library.verify import VERIFY

'''
###########################################################################################################
#
#                           R E A D E R - C L A S S - D E F I N I T I O N
#          
#       => Defines All Methods Needed To Read Inside The User Choosen File
#       => Some Methods Defined In The writer.py File Are Also Called In These Reader methods
#
###########################################################################################################
'''

class Reader:

    def __init__(self):

        '''
            File Name Of The .XLSX File To Open... Input File
        '''
        self.filename = None

        '''
            Hold All Strings To Be Used As Sheets In The Output File
        '''
        self.sheets_to_new_file = []

        '''
            Instance Of The Opened Input File
        '''
        self.work_book = None

        self.numberOfRowsMoved = 0

        '''
            Instance Of The Sheet In The Opened Input File
        '''
        self.work_sheet = None


    '''
        Method To Open The Specified File
        Create The WorkBook & WorkSheet Instance
    '''
    def add_xfile(self, filename):

        """
        :param filename: Path To The File You Want Open
        """

        '''
            Exception Handling For IO Operation
        '''
        try:

            '''
                Create WorkBook/ Open The Input File
            '''
            self.filename = filename
            self.work_book = open_workbook(self.filename)

            '''
                Get The First WorkSheet
            '''
            self.work_sheet = self.work_book.sheet_by_index(0)


        except IOError:

            '''
                Catch All IO Error
            '''
            print(IOError.filename)

    '''
        Get All Strings That Will Be Sheets In Output File
    '''
    def add_xtract_worksheets(self):


        '''
            All Sheets To Be Extracted Are On This Row
        '''
        sheetsRowIndex = 6

        '''
            Get The Output File WorkBook
        '''
        self.writer = xwriter.getWorkBook('./new files/output.xlsx')

        '''
            Iterate Through Only On The 6th Row
            From Column 4, It's Headers That Will Be Work Sheets On The New Structured File 
        '''
        for columnIndex in range(self.work_sheet.ncols):

            '''
                Sheets To Be Extracted Are From The 4th Column
            '''
            if columnIndex > 3:

                '''
                    Extracted Sheet String From Input File
                    It Will Be Used As A WorkBook Sheet In The Output Sheet
                '''
                sheetFromCell = self.work_sheet.cell(sheetsRowIndex, columnIndex).value

                '''
                    Process Sheet Strings To Make The Them WorkBook Sheets In Output File
                '''
                self.processSheetsExtracted(sheetFromCell, columnIndex)

        '''
            Close The Output File Workbook To Save Changes!
        '''
        xwriter.workBookClose()

        # xwriter.formatColumnSizes(self.filename)

        print("***************************************************************************\n*\n*\n*\t\t\t\t\t\t\tEXTRACTION PROCESS DONE\n*\n*\n*")
        print("***************************************************************************")

    '''
        Method To Start The Extraction Process Of The Sheet Strings
    '''
    def processSheetsExtracted(self, Sheet, columnIndex) :

        '''
        :param Sheet: Extracted Sheet
        :return: none
        '''

        crumbs = None

        '''
            Add Sheet To All Extracted Sheets List
        '''
        self.sheets_to_new_file.append(Sheet)

        VERIFY.countNumberOfRowsToMove(self.work_sheet, Sheet, columnIndex)

        self.numberOfRowsMoved = 0

        '''
            Iterate Through All Rows Of The WorkSheet
        '''
        for rowIndex in range(self.work_sheet.nrows) :

            '''
                Data For All Sheets Start From Row 7
            '''
            if rowIndex > 6 :

                '''
                    Extracted Data
                '''

                dateIndex = 0

                '''
                
                '''
                whereMonth = self.work_sheet.cell(2, columnIndex).value

                if whereMonth == 'Beginning of month' :

                    dateIndex = 0

                elif whereMonth == 'End of month' :

                    dateIndex = 1
                '''
                    EXtract Data From The Input File Excel Cells
                '''
                dateFromCell    = self.work_sheet.cell(rowIndex, dateIndex).value
                paymentFromCell = self.work_sheet.cell(rowIndex, columnIndex).value

                if paymentFromCell != "" :

	                self.numberOfRowsMoved += 1

                '''
                    Format Extracted Data
                '''
                self.formatExtractedData(Sheet, dateFromCell, paymentFromCell)

                dateForCrumbs = self.work_sheet.cell(7, dateIndex).value
                crumbs = self.formatCrumbsStatic(Sheet, dateForCrumbs)

        VERIFY.setNumberOfRowsMoved(self.numberOfRowsMoved)

        '''
            Creates Sheet In Output File
        '''
        xwriter.addWorkSheet(Sheet, crumbs)

    def formatCrumbsStatic(self, Sheet, date):

        '''
            Extract Data For Static Files
        '''

        y, month, d, h, m, s = xlrd.xldate_as_tuple(date, self.work_book.datemode)

        referenceIndex = ""

        '''
            Check If Sheet Contains "NEG" for The Reference Index
        '''
        if str(Sheet).find("NEG") != -1 :

            referenceIndex = "NRR_TAX_T_PR1246"

        else :

            referenceIndex = "NRR_TAX_T_PR79"

        '''
            Format The Data For Finishing The Static Data!
        '''
        crumbs = {

            "tradeRef"  : Sheet,
            "refIndex"  : referenceIndex,
            "transDate" : "{}/{}/{} 18:00".format(y, month, d)

        }

        '''
            Returns The Crumbs
        '''
        return crumbs

    '''
        Method To Format All Extracted Data
    '''
    def formatExtractedData(self, sheetName, rawDate, payment) :

        '''
        :param sheetName:
        :param rawDate:
        :param payment:
        :return: None
        '''

        '''
            Destructure The Date
        '''
        y, month, d, h, m, s = xlrd.xldate_as_tuple(rawDate, self.work_book.datemode)

        '''
            Try Adding Time!!
        '''
        date          = "{}/{}/{}".format(y, month, d)

        '''
            Format The Extracted Date In Dictionary For Key-Value, Ease Of Transmission 
        '''
        dataSet       = {

            "sheet_name"    : sheetName,
            "date"          : date,
            "payment"       : payment

        }

        '''
            Add Data Set To Writer For Writing In The Output File
        '''
        xwriter.addFormattedData(dataSet)
