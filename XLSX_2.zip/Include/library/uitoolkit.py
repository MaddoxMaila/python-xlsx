import os
from tkinter import *
from tkinter.ttk import *
from tkinter.filedialog import *
from Include.library.reader import Reader
from Include.library.verify import VERIFY

'''
    Class To Create The User Interface Of The Program!
'''
class UI() :

    def __init__(self):

        '''
            Tkinter Instance
        '''
        self.root        = Tk()

        '''
            
        '''
        self.buildui = False

        '''
            Window Frames
        '''
        self.mainFrame   = None

        '''
            Window Buttons 
        '''
        self.inputFileBtn = None

        '''
            Window Labels
        '''
        self.appLabel     = None

        '''
            File Paths
        '''
        self.pathToInputFile  = None
        self.pathToOutputFile = './new files/output.xlsx'


    '''
        Method To Build The Main Window Layout.
        Every Build Method Will Be Called Here
    '''
    def buildMainBody(self, width, height):

        '''
        :param width: Width Of The Window
        :param height: Height Of The Window
        :return: None
        '''

        '''
            Set The Minimum & Maximum Size Of The Window
        '''
        self.root.minsize(width, height)
        self.root.maxsize(width, height)

        self.buildui = True
        '''
            Build The UI
        '''
        self.buildUI()

        '''
            To Keep The Window On Screen, We Use The Mainloop
        '''
        self.root.mainloop()

    '''
        Calling This Will Add Space Between Elements
    '''
    def addSpaceBetween(self, height):

        '''
        :param height: Height Of The Space Wanted Between
        :return: None
        '''

        '''
            Space Frame, Creates The Space
        '''
        Frame(self.root, height=height).pack(side=TOP)

    '''
        Method To Build Frames
        
        *** Frames Are Base Layouts To Add Buttons In
    '''
    def buildUI(self)   :

        '''
        :return: None
        '''

        '''
            Root Level Frame
        '''
        self.mainFrame = Frame(self.root).pack(side = TOP)

        self.addSpaceBetween(10) # Add Space Between Ui Components

        '''
            Button That Will Let User Choose File
        '''
        self.inputFileBtn = Button(self.mainFrame, text = "Choose Input File", bg = "#5bc0de", fg = "#fff", highlightbackground = "#fff", height = 3, width = 20, font=('Helvetica', 10, 'bold'), cursor = "hand2")
        self.inputFileBtn.pack(side = TOP)

        self.addSpaceBetween(15) # Add Space Between Ui Components

        '''
            Label To Add Text To UI
        '''
        self.appLabel = Label(self.mainFrame, text = "No File Choosen", fg = "red", font = ('Helvetica', 18, 'bold'))
        self.appLabel.pack(side = TOP)

        self.addSpaceBetween(10) # All Space Between Ui Components

        '''
            On Button Click It Should Call chooseInputFile Method
        '''
        self.inputFileBtn['command'] = lambda : self.chooseInputFile()


    def setText(self, text, fontSize, color) :

        '''
        :param text: Text To Be Set
        :param fontSize: size Of The Text
        :param color: Color Of The Text
        :return: Nonr
        '''
        self.appLabel['text']   = text
        self.appLabel['fg']     = color
        self.appLabel['font']   =  ('Helvetica', fontSize, 'bold')

    def chooseInputFile(self) :

        '''
        :return: None
        '''

        '''
            Get Path To File That Is The Input File
            *.xlsx Is For Showing On Excel Files In An Opened Directory/ Sub Directory
        '''
        self.pathToInputFile = askopenfile(mode = "r", filetypes = [('Open An Excel File', '*.xlsx')])

        '''
            Check If A Valid Path Was Returned!
        '''
        if self.pathToInputFile is not None :

            '''
                Since A File Was Choosen
                Hide The Choose Input File Button
                Show The Start Extraction Process Button!
            '''
            self.inputFileBtn.pack_forget()

            '''
                Show The Path File Choosen To The User
            '''
            self.setText(self.pathToInputFile.name, 6, "#5cb85c")

            '''
                Show The Start Extraction Button
            '''
            self.addStartProcessBtn()

        else :

            '''
                Show Error
            '''
            self.setText("File Was Not Chosen", 18, "red")


    '''
        Add Button To UI That Would Start Extraction Process On Click
    '''
    def addStartProcessBtn(self)    :

        '''
        :return: None
        '''

        '''
            Create Button To Start The Whole Extraction Process On Click
        '''
        self.startProcessBtn = Button(self.mainFrame, text = "Start Extraction Process", bg = "#5cb85c", fg = "#fff", highlightbackground = "#fff", height = 3, width = 20, font=('Helvetica', 10, 'bold'), cursor = "hand2")
        self.startProcessBtn.pack(side = TOP)

        '''
            Hook Method To Button Click
        '''
        self.startProcessBtn['command'] = lambda : self.startExtractionProcess()


    '''
        Method To Handle The Extraction Process
    '''
    def startExtractionProcess(self):

        '''
        :return: None
        '''

        '''
            Check Again If Path Is Not None
        '''
        if self.pathToInputFile is not None:

            '''
                Call Methods From The Reader Class in reader.py
            '''
            self.setText("Extracting...", 15, "#5cb85c")

            '''
                This Method Call Kickstarts The Extraction Process
            '''
            self.readerFormater()


        else:

            '''
                On Failure!
            '''
            self.setText("File Not Defined", 18, "red")


        '''
            Add Space
        '''
        self.addSpaceBetween(15)

    '''
        Formats The Response The User Receives Either On The UI or Console
    '''
    def readerFormater(self):

        '''
        :return: None
        '''

        if self.buildui:

            '''
                Set Path To The Choosen One Through The User Interface
            '''
            path = self.pathToInputFile.name

            '''
                Call Extraction Method
            '''
            self.methodsFromReader(path)

            '''
                Show Success Response
            '''
            self.setText("Extraction Done!", 18, "#5cb85c")

            '''
                Remove The Extraction Button! On Extraction Done!
            '''
            self.startProcessBtn.pack_forget()

        else:

            '''
                If The User Interface Was Not Build, Hardcode The Path
            '''
            path = './original file/Input_Nominal_PRO (Pasted Values)_T (1).xlsx'
            self.methodsFromReader(path)

            '''
                Show Success Response
            '''
            print("\n\t\t\t\t\tE X T R A C T I O N S U C C E S S")
            print("\n###########################################################################")


    '''
        All Reader Objects And Methods Are Called Here!
    '''
    def methodsFromReader(self, path):

        '''
            Create Reader Object To Start The Extraction Process
        '''
        read = Reader()

        '''
            Add The Choosen File
        '''
        read.add_xfile(path)

        '''
            Begin With The Extraction Of Sheets Process
        '''
        read.add_xtract_worksheets()

    '''
        The Method To Call After Initializing a UI object!
        Comes With Default Parameters If You Don't Really Wanna Configure It!
        
        You Call The Method Like This
        
        ui = UI()
        
        => ui.main() *** Will Run The Program With Default Params Without Creating The Interface
        => ui.main(True) *** Will Create The User Interface With Default Height & Width
        => ui.main(True, xxx, xxx) *** Will Create The UI With Your Custom Height & Width

    '''
    def main(self, buildUi = False, width = 300, height = 125) :

        '''
        :param width: Width For The Build Window
        :param height: Height For The Build Window
        :return: None
        '''

        '''
            Build UI variable Which Controls If You Want The UI To Be Built
            Or Just Use The Console Application
        '''
        self.buildui = buildUi

        '''
            Check If self.buildui is True OR False
        '''
        if self.buildui :

            '''
                On True buildui, Call build Methods To Build The User Interface
            '''
            self.buildMainBody(width, height)

        else    :

            '''
                Other Than That Run The Program Like Nothing Happened!
            '''
            self.readerFormater()
