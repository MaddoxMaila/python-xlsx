

'''
###############################################################################################################
#
#                       Defines All Static Vars That Are Not Defined In The Input File
#
###############################################################################################################
'''

def setStaticList(args) :

    '''
    :return: None
    '''

    '''
        Holds The Static Lists
        Every Entry In Each List Maps To It's Counter Part
    '''
    info = {

        "columnOne" : [
            'specificType',
            'contractSubType',
            'tradeReference',
            'systemDate',
            'transactionDate',
            'reissuedDate',
            'reissuedReference',
            'book',
            'counterParty',
            'numberOfUnits',
            'specialInfo1',
            'specialInfo2',
            'collateralInfoType',
            'FundingStatus',
            'workFlowReference',
            'riskDefinition',
            'externalReference',
            'csa',
            'dataExportInfo',
            'referenceIndex',
            'currency',
            'businessDayConvention',
            'businessCenter'
        ],

        "columnTwo" : [
            'cashFlowStream',
            'Cashflow(Stream)',

            args['tradeRef'],

            '10/18/2016 16:43',

            args['transDate'],
            ' ',
            ' ',
            'L:LG:ALM MRM EDS AND NRR:NRR CURVE:T',
            'Liberty Life BU|Global MArkets Liberty',
            1,
            ' ',
            ' ',
            0,
            'Unfunded',
            ' ',
            'TRADING',
            ' ',
            ' ',
            ' ',
            args['refIndex'],
            
            'ZAR',
            'MODIFIED FOLLOWING',
            'ZAJO'
        ]

    }

    return info
