import xlsxwriter as xwriter
from library.static import setStaticList
from Include.library.verify import VERIFY
'''
#########################################################################################################
#
#                           W R I T E - M E T H O D S - D E F I N I T I O N
#
#########################################################################################################
'''


'''
    Opened WorkBook, instance of xwriter.WorkBook
'''
workBook = xwriter.Workbook('./new files/output.xlsx')

'''
    Hold All WorkSheets For This WorkBook
'''
workSheetsList = []

'''
    Currently Opened WorkSheet
'''
currentWorkSheet = None #workBook.add_worksheet()

'''
    Holder To Hold All Specially Formatted Data Collected From Input File
'''
formattedData = []

'''
    Format Styling For The Merging
'''
mergeFormat = workBook.add_format({
    'bold' : 1,
    'border': 1,
    'align': 'center',
    'valign': 'vcenter',
    'fg_color': 'white'})

format = workBook.add_format()

format.set_text_wrap()

'''
    Get WorkBook To Use
'''
def getWorkBook(filename) :

    '''
    :param filename: Path To File
    :return: xwriter.WorkBook Instance
    '''
    return workBook


'''
    Add WorkSheet To The Currently Opened WorkBook
'''
def addWorkSheet(sheet, crumbsForStatic) :

    '''
    :param sheet: Worksheets For The WorkBook
    :return: None

        This Is The Brain Of The Program. Most Stuff Happens Here!

        1. Firstly Add A WorkSheet To The WorkBook
        2. Add Headers To Specify Which Type Of Data Is
        3. Add The Data!

    '''

    '''
        Add WorkSheet To Work
    '''
    currentWorkSheet = None
    currentWorkSheet = workBook.add_worksheet(sheet)

    '''
        Dictionary To Hold The WorkSheet Name & Instance As Key/Value.
        During Iteration, We'll Just Use The Sheet Name ** :param sheet ** To Choose Which
        WorkSheet To Use
    '''
    # SheetDict = {
    #     sheet   : currentWorkSheet
    # }

    '''
        Add All WorkSheet To A Global Array
    '''
    workSheetsList.append(sheet)


    '''
        Universal Row Index Of The Entire Workd Sheet
    '''
    rowIndex = 0

    '''
        Get The Static Data
    '''
    dataFromStatic = setStaticList(crumbsForStatic)

    '''
        Iterate Through The Two Lists In Parallel
    '''
    column = 0
    columnOneWidth = 20
    columnTwoWidth = 20

    for columnOne, columnTwo in zip(dataFromStatic["columnOne"], dataFromStatic["columnTwo"]) :


        if columnOne == "tradeReference" or columnOne == "transactionDate" or columnOne == "referenceIndex" :

            format = None
            format = workBook.add_format()
            format.set_bg_color("yellow")
            format.set_text_wrap()

        else :

            format = None

            format = workBook.add_format()
            format.set_text_wrap()



        '''
            Write To The First Column
        '''
        currentWorkSheet.write(rowIndex, column, columnOne, workBook.add_format().set_text_wrap())

        '''
            Write To The Second Column
        '''
        currentWorkSheet.write(rowIndex, column + 1, columnTwo, format)

        rowIndex += 1

    '''
        Add Headers For Dynamic Data!
    '''

    dateColumnIndex = 1
    paymentColumn   = 2

    currentWorkSheet.write(rowIndex, 0, 'CashFlowSchedule', mergeFormat.set_text_v_align("center"))
    currentWorkSheet.write(rowIndex, dateColumnIndex, 'Date', mergeFormat)
    currentWorkSheet.write(rowIndex, paymentColumn, 'Payment', mergeFormat)

    currentWorkSheet.merge_range("A{}:A{}".format(rowIndex + 1, VERIFY.getNumberOfRowsToMove() + 24), "CashFlowSchedule")

    '''
        Iterate Through The Formatted Data To Retrieve The Rows Stored In 
        This Format {"sheet_name" : "xxx", "date" : "xxx", "data" : "xxx"}
    '''

    '''
        Start Iteration
    '''
    rowIndex += 1

    '''
       Variable To Keep How Many Rows Were Inserted For Comparing With Number Of Rows Extracted
    '''
    counter = 0
    
    for singleRowData in formattedData :

        '''
            Check If Sheet Name Passed As Argument Is Same As Sheet Name Stored
        '''
        if sheet == singleRowData['sheet_name'] :

            ''' True :=> Continue With Operation '''

            '''
                Add Date
            '''
            currentWorkSheet.write(rowIndex, dateColumnIndex, singleRowData['date'], format)

            '''
                Add Payment
            '''
            currentWorkSheet.write(rowIndex, paymentColumn, singleRowData['payment'], format)

            ''' Increment The Row Index! '''
            rowIndex += 1
            counter += 1

    VERIFY.setNumberOfRowsInOutput(counter)

'''
    Close Currently Opened WorkBook.
    
    **** Any Changes Made To The File Won't Save Without Calling This Method
'''
def workBookClose() :

    '''
    :return: None
    '''

    '''
        Close The WorkBook
    '''
    workBook.close()

'''
    Write To The The Current WorkSheet
'''
def writeToWorkingSheet(row, column, data) :

    """
    :param colomn: Colomn Number To Write To
    :param row:    Row Number To Write To
    :param data:   Data To Write
    """

    currentWorkSheet.write(row, column, data)

def addFormattedData(dictionary) :

    formattedData.append(dictionary)
