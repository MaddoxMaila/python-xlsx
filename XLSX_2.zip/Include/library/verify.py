


'''
		
		"Verify" IS A CLASS THAT WILL VERIFY THE INTERGRITY OF THE DATA EXPORTED AND IMPORTED 

'''


class Verify :


	def __init__(self) :

		self.numberOfRowsToMove = 0
		self.numberOfRowsMoved 	= 0
		self.numberOfRowsInOutput = 0
		self.sheetName          = ''

	def getNumberOfRowsMoved(self):

		return self.numberOfRowsMoved

	def getNumberOfRowsToMove(self):

		return self.numberOfRowsToMove

	def getNumberOfRowsInOutput(self):

		return self.numberOfRowsInOutput

	def setNumberOfRowsInOutput(self, numberOfRows):

		self.numberOfRowsInOutput = numberOfRows

		print("\tNumber Of Rows In Output File : {} ROWS Out Of {} ROWS\n\n".format(self.numberOfRowsInOutput, self.numberOfRowsToMove))

	def setNumberOfRowsToMove(self, numberOfRows):

		self.numberOfRowsToMove = numberOfRows

		print("###### FOR {} SHEET ######\n\n\tExpected Number Of Rows To Move : {} ROWS".format(self.sheetName ,self.numberOfRowsToMove))

	def setNumberOfRowsMoved(self, numberOfRows):

		self.numberOfRowsMoved = numberOfRows

		print("\tNumber Of Rows Moved : {} ROWS Out Of {} ROWS".format(self.numberOfRowsMoved, self.numberOfRowsToMove))

	def countNumberOfRowsToMove(self, workSheet, SheetName, columnIndex):


		'''

		:param workSheet:
		:param SheetName:
		:param columnIndex:
		:return:
		'''

		'''
			
		'''

		counter = 0
		self.sheetName = SheetName

		for rowIndex in range(workSheet.nrows) :

			if rowIndex > 6 :

				paymentData = workSheet.cell(rowIndex, columnIndex).value

				if paymentData != "" :

					counter += 1

		self.setNumberOfRowsToMove(counter)





VERIFY = Verify()