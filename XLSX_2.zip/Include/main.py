from library.uitoolkit import UI
from Include.library.verify import VERIFY

''' 
############################################################################################################
#
#                           				M A I N - E N T R Y - P O I N T
#           
#           => Built On Jetbrains PyCharm IDE
#           => 1st Configure Your Project By Installing The Following Modules On The Command Prompt In Your
#              Project Directory
#              
#              *** pip install XlsxWriter
#              *** pip install xlrd
#              
#               Run main.py With The Following Configs Passed To Method ui.main()
#
#           => ui.main() *** Will Run The Program With Default Params Without Creating The Interface
#           => ui.main(False) *** Will Run The Program With Default Params Without Creating The Interface
#           => ui.main(True) *** Will Create The User Interface With Default Height & Width
#           => ui.main(True, xxx, xxx) *** Will Create The UI With Your Custom Height & Width
#               
#
############################################################################################################
'''

'''
    Create The User Interface UI
'''
ui = UI()

'''
    Runs The Program According To Your Configurations
'''
ui.main(buildUi = False, width = 300, height = 125)